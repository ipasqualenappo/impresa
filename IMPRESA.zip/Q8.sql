/*QUERY 8*/
insert into attoAffitto values("2312","2015-05-29", "1237");
insert into elencazioneBom values("1242", "1237");
update bombola set stato= "in affitto" where codice = "1242"