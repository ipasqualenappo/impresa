/*QUERY 12*/
select codice from bombola where scadenza=2015-04-15