/* QUERY 5*/
insert into intermediario values("1432","Annunziata","annunziata@gmail.com","22","Annunziata","80060");
insert into intermediazione values("Annunziata","Annunziata","12");
insert into telefonoInt values("0818659875","Annunziata");
insert into faxInt values("0818659575","Annunziata");