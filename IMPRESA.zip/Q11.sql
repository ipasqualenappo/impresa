/*	QUERY 11*/
select count(*) from bombola where stato="in affitto"