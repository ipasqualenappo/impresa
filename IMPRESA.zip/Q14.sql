/*QUERY14*/
select distinct M.codice from attoMateriali as M , attoTrasporto as T where M.codice=T.attoMateriali