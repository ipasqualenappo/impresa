import java.sql.*;
import java.sql.Statement;
import java.sql.Connection;
import java.util.Scanner;
import java.io.*;
import com.mysql.jdbc.*;
 
 
public class ConnessioneImpresa {
    private static Connection connessione;
     
    public static void main(String args[]) throws Exception {
        ConnessioneImpresa cc=new ConnessioneImpresa();
        cc.getConnection();
        System.out.println("SCEGLI QUALE OPERAZIONE ESEGUIRE:");
        for(int i=1; i<15; i++){
            System.out.println(i+" - OP"+i);
        }
        cc.creamenu();  
    }
     
    public ConnessioneImpresa() throws InstantiationException, IllegalAccessException{
        try{
            Class.forName("com.mysql.jdbc.Driver");     //INSTANZAZIONE DEL DRIVER CON COMANDO newIstance();
        }
        catch(ClassNotFoundException e){
            System.out.print("ClassNotFoundException:" + e.getMessage());   
        }
    }   
      
    public void getConnection(){
        try{
        String url= "jdbc:mysql://localhost:3306/impresa";
        connessione = DriverManager.getConnection(url,"root","root");
        System.out.println("Connessione OK \n");
        }
    catch(SQLException e){
        System.out.println("Connessione fallita \n");
        System.out.println(e);
        }
    }
      
    public void creamenu() throws SQLException, FileNotFoundException{
        Scanner inp=new Scanner(System.in);
        System.out.println("\nInserisci il numero dell'operazione:");
        String scelta=inp.nextLine();
        while(!scelta.equalsIgnoreCase("esc")){
            switch(scelta){
                case "1":{
                    try{
                        Statement st=connessione.createStatement();
                        File qw=new File("q1.sql");
                        Scanner as=new Scanner(qw);
                        String gf="";
                        while(as.hasNextLine()){
                            gf=as.nextLine();
                            st.executeUpdate(gf);
                            System.out.println("Esecuzione...");
                        }
                        System.out.println("\nQUERY 1 EFFETTUATA!\n");
                        String sql="select * from fonderia";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nOUTPUT:");
                        while(set.next()){
                        	String codpar=set.getString("codpar");
                            String nominativo=set.getString("nominativo");
                            String email=set.getString("email");
                            String nciv=set.getString("nciv");
                            String via=set.getString("via");
                            int cap=set.getInt("cap");                            
                            System.out.println(""+"[codpar:"+codpar+"]"+"[nominativo:"+nominativo+"]"+"[email:"+email+"]"+"[nciv:"+nciv+"]"+"[via:"+via+"]"+"[cap:"+cap+"]"); 

                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }   
                    break;
                }
                case "2":{
                    try{
                        Statement st=connessione.createStatement();
                        File qw=new File("q2.sql");
                        Scanner as=new Scanner(qw);
                        String gf="";
                        while(as.hasNextLine()){
                            gf=as.nextLine();
                            st.executeUpdate(gf);
                            System.out.println("Esecuzione...");
                        }
                        System.out.println("\nQUERY 2 EFFETTUATA!");
                        String sql="select * from trasportatore";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nOUTPUT:");
                        while(set.next()){
                            String codpar=set.getString("codpar");
                            String nominativo=set.getString("nominativo");
                            String email=set.getString("email");
                            String nciv=set.getString("nciv");
                            String via=set.getString("via");
                            int cap=set.getInt("cap");
                           
                            System.out.println(""+"[codpar:"+codpar+"]"+"[nominativo:"+nominativo+"]"+"[email:"+email+"]"+"[nciv:"+nciv+"]"+"[via:"+via+"]"+"[cap:"+cap+"]");    
                        }
                        set.close();
                        st.close();
                        }catch(SQLException ex){
                            System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                    }
                case "3":{
                    try{
                        Statement st = connessione.createStatement();
                        String sql="select * from fornitore";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nQUERY 3 EFFETTUATA!\n");
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codpar=set.getString("codpar");
                            String nominativo=set.getString("nominativo");
                            String email=set.getString("email");
                            String nciv=set.getString("nciv");
                            String via=set.getString("via");
                            int cap=set.getInt("cap");
                            
                            System.out.println(""+"[codpar:"+codpar+"]"+"[nominativo:"+nominativo+"]"+"[email:"+email+"]"+"[nciv:"+nciv+"]"+"[via:"+via+"]"+"[cap:"+cap+"]");    
                        }   
                       set.close();
                       st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "4":{
                    try{
                    Statement st=connessione.createStatement();
                    File qw=new File("Q4.sql");
                    Scanner as=new Scanner(qw);
                    String gf="";
                    while(as.hasNextLine()){
                        gf=as.nextLine();
                        st.executeUpdate(gf);
                        System.out.println("Esecuzione...");
                    }
                    System.out.println("\nQUERY 4 EFFETTUATA!\n");
                    String sql="select * from affittuario";
                    ResultSet set=st.executeQuery(sql);
                    System.out.println("OUTPUT:");
                    while(set.next()){
                        String codpar=set.getString("codpar");
                        String nominativo=set.getString("nominativo");
                        String email=set.getString("email");
                        String nciv=set.getString("nciv");
                        String via=set.getString("via");
                        int cap=set.getInt("cap");
                        
                        System.out.println(""+"[codpar:"+codpar+"]"+"[nominativo:"+nominativo+"]"+"[email:"+email+"]"+"[nciv:"+nciv+"]"+"[via:"+via+"]"+"[cap:"+cap+"]");      
                    }
                    set.close();
                    st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "5":{
                    try{
                        Statement st = connessione.createStatement();
                        String sql="select * from intermediario";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nQUERY 5 EFFETTUATA!\n");
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codpar=set.getString("codpar");
                            String nominativo=set.getString("nominativo");
                            String email=set.getString("email");
                            String nciv=set.getString("nciv");
                            String via=set.getString("via");
                            int cap=set.getInt("cap");
                            
                            System.out.println(""+"[codpar:"+codpar+"]"+"[nominativo:"+nominativo+"]"+"[email:"+email+"]"+"[nciv:"+nciv+"]"+"[via:"+via+"]"+"[cap:"+cap+"]");    
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "6":{
                    try{
                        Statement st=connessione.createStatement();
                        File qw=new File("Q6.sql");
                        Scanner as=new Scanner(qw);
                        String gf="";
                        while(as.hasNextLine()){
                            gf=as.nextLine();
                            st.executeUpdate(gf);
                            System.out.println("Esecuzione...");
                        }
                        System.out.println("\nQUERY 6 EFFETTUATA!\n");
                        String sql="select *from attoMateriali";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codice=set.getString("codice");
                            String data=set.getString("data");
                            String fonderia=set.getString("fonderia");
                            String fornitore=set.getString("fornitore");
                            System.out.println("[codice:"+codice+"] "+"[data:"+data+"] "+"[fonderia:"+fonderia+"]"+"[fornitore:"+fornitore+"]");
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "7":{
                    try{
                        Statement st=connessione.createStatement();
                        File qw=new File("Q7.sql");
                        Scanner as=new Scanner(qw);
                        String gf="";
                        while(as.hasNextLine()){
                            gf=as.nextLine();
                            st.executeUpdate(gf);
                            System.out.println("Esecuzione...");
                        }
                        System.out.println("\nQUERY 7 EFFETTUATA!\n");
                        String sql="select * from attoMateriali";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codice=set.getString("codice");
                            String data=set.getString("data");
                            String fonderia =set.getString("fonderia");
                            String fornitore=set.getString("fornitore");
                            System.out.println("[codice:"+codice+"] "+"[data:"+data+"] "+"[fonderia:"+fonderia+"]"+" [fornitore:"+fornitore+"] ");
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "8":{
                    try{
                        Statement st = connessione.createStatement();
                        String sql="select * from attoAffitto";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nQUERY 8 EFFETTUATA!\n");
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codice=set.getString("codice");
                            String data=set.getString("data");
                            String affittuario=set.getString("affittuario");
                            System.out.println("[codice: "+codice+"]"+"[data:"+data+"]"+"[affittuario:"+affittuario+"]");
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "9":{
                    try{
                        Statement st=connessione.createStatement();
                        File qw=new File("Q9.sql");
                        Scanner as=new Scanner(qw);
                        String gf="";
                        while(as.hasNextLine()){
                            gf=as.nextLine();
                            st.executeUpdate(gf);
                            System.out.println("Esecuzione...");
                        }
                        System.out.println("\nQUERY 9 EFFETTUATA!\n");
                        String sql="select *from attoAffitto";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codice=set.getString("codice");
                            String data=set.getString("data");
                            String affittuario=set.getString("affittuario");
                            System.out.println("[codice:"+codice+"] "+"[data:"+data+"]"+"[affittuario:"+affittuario+"]");
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "10":{
                    try{
                        Statement st=connessione.createStatement();
                        File qw=new File("Q10.sql");
                        Scanner as=new Scanner(qw);
                        String gf="";
                        while(as.hasNextLine()){
                            gf=as.nextLine();
                            st.executeQuery(gf);
                            System.out.println("Esecuzione...");
                        }
                        System.out.println("\nQUERY 10 EFFETTUATA!\n");
                        String sql="select *from bombola";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codice=set.getString("codice");
                            int capacita=set.getInt("capacita");
                            String scadenza=set.getString("scadenza");
                            String stato=set.getString("stato");
                            int prezzo=set.getInt("prezzo");
                            String gas=set.getString("gas");
                          System.out.println("[codice:"+codice+"]"+"[capacita:"+capacita+"]"+"[scadenza:"+scadenza+"]"+"[stato:"+stato+"]"+"[prezzo:"+prezzo+"]"+"[gas:"+gas+"]");                                             
                        }
                        
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "11":{
                    try{
                        Statement st = connessione.createStatement();
                        String sql="select *from bombola";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nQUERY 11 EFFETTUATA!\n");
                        System.out.println("OUTPUT:");
                        while(set.next()){
                        	String codice=set.getString("codice");
                            int capacita=set.getInt("capacita");
                            String scadenza=set.getString("scadenza");
                            String stato=set.getString("stato");
                            int prezzo=set.getInt("prezzo");
                            String gas=set.getString("gas");
                          System.out.println("[codice:"+codice+"]"+"[capacita:"+capacita+"]"+"[scadenza:"+scadenza+"]"+"[stato:"+stato+"]"+"[prezzo:"+prezzo+"]"+"[gas:"+gas+"]");
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "12":{
                    try{
                        Statement st=connessione.createStatement();
                        File qw=new File("Q12.sql");
                        Scanner as=new Scanner(qw);
                        String gf="";
                        while(as.hasNextLine()){
                            gf=as.nextLine();
                            st.executeQuery(gf);
                            System.out.println("Esecuzione...");
                        }
                        System.out.println("\nQUERY 12 EFFETTUATA!\n");
                        String sql="select * from bombola";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("OUTPUT:");
                        while(set.next()){
                        	    String codice=set.getString("codice");
                                int capacita=set.getInt("capacita");
                                String scadenza=set.getString("scadenza");
                                String stato=set.getString("stato");
                                int prezzo=set.getInt("prezzo");
                                String gas=set.getString("gas");
                              System.out.println("[codice:"+codice+"]"+"[capacita:"+capacita+"]"+"[scadenza:"+scadenza+"]"+"[stato:"+stato+"]"+"[prezzo:"+prezzo+"]"+"[gas:"+gas+"]");   
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "13":{
                    try{
                        Statement st = connessione.createStatement();
                        String sql="select * from affittuario";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nQUERY 13 EFFETTUATA!\n");
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codpar=set.getString("codpar");
                            String nominativo=set.getString("nominativo");
                            String email=set.getString("email");
                            String nciv=set.getString("nciv");
                            String via=set.getString("via");
                            int cap=set.getInt("cap");
                            System.out.println("[codpar:"+codpar+"] "+"[nominativo:"+nominativo+"] "+"[email:"+email+"]"+"[nciv:"+nciv+"]"+"[via:"+via+"]"+"[cap:"+cap+"]");
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "14":{
                    try{
                    	Statement st = connessione.createStatement();
                        String sql="select * from attoMateriali";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nQUERY 14 EFFETTUATA!\n");
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codice=set.getString("codice");
                            String data=set.getString("data");
                            String fonderia=set.getString("fonderia");
                            String fornitore=set.getString("fornitore");
                            
                            System.out.println("[codice:"+codice+"] "+"[data:"+data+"] "+"[fonderia:"+fonderia+"]"+"[fornitore:"+fornitore+"]");
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                case "15":{
                    try{
                    	Statement st = connessione.createStatement();
                        String sql="select * from metallo";
                        ResultSet set=st.executeQuery(sql);
                        System.out.println("\nQUERY 15 EFFETTUATA!\n");
                        System.out.println("OUTPUT:");
                        while(set.next()){
                            String codice=set.getString("codice");
                            String nome=set.getString("nome");
                            int quantita=set.getInt("quantita");
                            String resa=set.getString("resa");
                            
                            System.out.println("[codice:"+codice+"] "+"[nome:"+nome+"] "+"[quantita:"+quantita+"]"+"[resa:"+resa+"]");
                        }
                        set.close();
                        st.close();
                    }catch(SQLException ex){
                        System.out.println("SQLException: "+ ex.getMessage());
                    }
                    break;
                }
                default:{ System.out.println("Scelta non presente"); break;}
            }
        System.out.println("\nSe vuoi continuare digita quale operazione effettuare, altrimenti digita esc");
        scelta=inp.nextLine();
        }
        System.out.println("CONNESSIONE TERMINATA!");
        connessione.close();
    }
}