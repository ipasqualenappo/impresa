/*QUERY 9*/
insert into attoTrasporto values("5678","2015-05-24","200","Rossi","300");