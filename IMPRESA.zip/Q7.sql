/*QUERY 7*/
insert into attoMateriali values("1239","2015-05-15",null,"1236");
insert into elencazioneMet values("ferro","attoferro","50","10");
update metallo set quantita = quantita - 10 where codice = 3245