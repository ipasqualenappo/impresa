/*QUERY 1*/
insert into fonderia values("1234","Bianco","bianco@gmail.com","3","Via Rossi","80040");
insert into telefonoFon values("815285459","Bianco");
insert into faxFon values("0815284579","Bianco");