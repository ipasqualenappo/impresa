/*QUERY 15*/
select codice, nome, quantita from metallo
