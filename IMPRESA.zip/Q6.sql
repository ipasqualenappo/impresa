/*QUERY 6*/
insert into attoMateriali values("4321","2015-04-13","Nappo",null);
insert into elencazioneMet values("ferro","300","50","10");
update metallo set quantita = quantita-10 where codice = "4321"