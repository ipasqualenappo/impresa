/*QUERY 4 */
insert into affittuario values("1322","Settembre","settembre@gmail.com","23","Settembre","80050");
insert into telefonoAff values("0814657245","Settembre");
insert into faxAff values("0818652457","Settembre");