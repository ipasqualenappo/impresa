/*QUERY 3*/
insert into fornitore values("1280","Avino","avino@gmail.com","23","Avino","80040");
insert into telefonoFor values("0815245258", "Avino");
insert into faxFor values("0818654579","Avino");