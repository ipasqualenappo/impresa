/*QUERY 13*/
select Af.codpar, max(At.data) as Data
from affittuario as Af, attoAffitto as At 
where At.data = 2015-04-12 and Af.codpar=At.affittuario
group by Af.codpar