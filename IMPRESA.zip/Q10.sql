/*QUERY 10*/
select count(*) from bombola where stato='vuota'