/*QUERY 2 */
insert into trasportatore values("1235" ,"Rossi","rossi@gmail.com","34","Rossi", "80040");
insert into telefonoTra values("0815285457","Rossi");
insert into faxTra values("0815242657","Rossi");